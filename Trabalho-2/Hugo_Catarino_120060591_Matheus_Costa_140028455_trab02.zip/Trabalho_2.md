﻿# Sistema operacional usado:


Elementary OS Loki com kernel 4.11.4-041104-generic


# Ambiente de desenvolvimento usado:


Mips


# instruções de uso 


Primeira entrada é o provável número primo (o módulo) m;
Segunda entrada é um número inteiro a.


# Limitações conhecidas


O número inteira a (segunda entrada) não pode ser maior que m (primeira entrada).